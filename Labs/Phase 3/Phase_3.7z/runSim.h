#ifndef runSim_H
#define runSim_H

// Header files.
#include <stdio.h>
#include <stdlib.h>
#include "StringUtils.h"
#include "configops.h"
#include "runSim.h"

// function prototypes
void runSim(ConfigDataType* configDataPtr, OpCodeType* mdData);
#endif