﻿#include "configops.h"
#include "metadataops.h"
#include "runSim.h"
#include "StringUtils.h"


void runSim(ConfigDataType* configData, OpCodeType* opCodes) {

	printf("===== ▪▪▪▪▪▪▪ ======\n");
	printf("runSim called here\n\n");

}